public class Main {
    public static void main(String[] args) {
        CarroEletrico carro = new CarroEletrico("Bi ai di");
        MotoGasolina moto = new MotoGasolina("bros 160");

        carro.acelerar();
        carro.frear();
        carro.carregarBateria();

        System.out.println();

        moto.acelerar();
        moto.frear();
        moto.abastecer();
    }
}
