public class CarroEletrico extends Veiculo implements Eletrico {

    public CarroEletrico(String modelo) {
        super(modelo);
    }

    @Override
    public void acelerar() {
        System.out.println(modelo + " está acelerando silenciosamente.");
    }

    @Override
    public void frear() {
        System.out.println(modelo + " está freando com recuperação de energia.");
    }

    @Override
    public void carregarBateria() {
        System.out.println(modelo + " está carregando a bateria.");
    }
}
