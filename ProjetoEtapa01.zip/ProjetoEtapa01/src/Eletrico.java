public interface Eletrico {
    void carregarBateria();
}
