public interface Combustivel {
    void abastecer();
}
