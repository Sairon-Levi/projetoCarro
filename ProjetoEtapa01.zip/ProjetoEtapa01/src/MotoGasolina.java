public class MotoGasolina extends Veiculo implements Combustivel {

    public MotoGasolina(String modelo) {
        super(modelo);
    }

    @Override
    public void acelerar() {
        System.out.println(modelo + " está acelerando com barulho do motor.");
    }

    @Override
    public void frear() {
        System.out.println(modelo + " está freandp.");
    }

    @Override
    public void abastecer() {
        System.out.println(modelo + " está enchendo o tanque.");
    }
}
